/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: '#e11d48',
        background: '#0a0a0f',
        surface: '#13131a',
        border: '#1f1f2e',
      },
    },
  },
  plugins: [],
}
