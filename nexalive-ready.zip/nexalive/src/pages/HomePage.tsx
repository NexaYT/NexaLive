import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '@/integrations/supabase/client'
import { useAuth } from '@/lib/auth-context'
import { Tv, LogOut, User, Play } from 'lucide-react'

interface Channel {
  id: string
  name: string
  stream_url: string
  logo_url?: string
  category?: string
}

export default function HomePage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [channels, setChannels] = useState<Channel[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchChannels()
  }, [])

  const fetchChannels = async () => {
    try {
      const { data, error } = await supabase
        .from('channels')
        .select('*')
        .order('name')

      if (error) throw error
      setChannels(data || [])
    } catch (err) {
      console.error('Channel load error:', err)
      // Show sample channels if DB not set up
      setChannels([
        { id: '1', name: 'Demo Channel 1', stream_url: '', category: 'News' },
        { id: '2', name: 'Demo Channel 2', stream_url: '', category: 'Sports' },
        { id: '3', name: 'Demo Channel 3', stream_url: '', category: 'Entertainment' },
      ])
    } finally {
      setLoading(false)
    }
  }

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    navigate('/auth')
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      {/* Navbar */}
      <header className="sticky top-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-[#1f1f2e]">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <svg viewBox="0 0 40 40" width="32" height="32">
              <defs>
                <linearGradient id="nx-g2" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
                  <stop offset="0" stopColor="#e11d48" />
                  <stop offset="1" stopColor="#f97316" />
                </linearGradient>
              </defs>
              <path d="M6 20a14 14 0 0 1 28 0" fill="none" stroke="url(#nx-g2)" strokeWidth="2.2" strokeLinecap="round" opacity="0.55" />
              <path d="M11 20a9 9 0 0 1 18 0" fill="none" stroke="url(#nx-g2)" strokeWidth="2.2" strokeLinecap="round" opacity="0.85" />
              <circle cx="20" cy="24" r="7.5" fill="url(#nx-g2)" />
              <path d="M18 21.2 L24 24 L18 26.8 Z" fill="white" />
            </svg>
            <span className="text-lg font-extrabold">
              <span className="text-red-500">Nexa</span>Live
            </span>
          </div>

          <div className="flex items-center gap-3">
            {user ? (
              <>
                <div className="flex items-center gap-2 text-sm text-gray-300">
                  {user.user_metadata?.avatar_url ? (
                    <img src={user.user_metadata.avatar_url} className="w-8 h-8 rounded-full" alt="avatar" />
                  ) : (
                    <User className="w-5 h-5" />
                  )}
                  <span className="hidden sm:inline">{user.user_metadata?.full_name || user.email}</span>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1.5 text-sm text-gray-400 hover:text-white transition-colors px-3 py-1.5 rounded-lg hover:bg-[#1f1f2e]"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="hidden sm:inline">Sign out</span>
                </button>
              </>
            ) : (
              <button
                onClick={() => navigate('/auth')}
                className="bg-red-600 hover:bg-red-700 text-white text-sm font-semibold px-4 py-2 rounded-lg transition-colors"
              >
                Login
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <div className="max-w-7xl mx-auto px-4 pt-10 pb-6">
        <h1 className="text-3xl sm:text-4xl font-extrabold mb-2">
          লাইভ <span className="text-red-500">চ্যানেল</span>
        </h1>
        <p className="text-gray-400">আপনার পছন্দের চ্যানেল বেছে নিন</p>
      </div>

      {/* Channels Grid */}
      <div className="max-w-7xl mx-auto px-4 pb-16">
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {[...Array(10)].map((_, i) => (
              <div key={i} className="bg-[#13131a] rounded-xl aspect-video animate-pulse" />
            ))}
          </div>
        ) : channels.length === 0 ? (
          <div className="text-center py-20 text-gray-500">
            <Tv className="w-12 h-12 mx-auto mb-3 opacity-40" />
            <p>কোনো চ্যানেল পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {channels.map(ch => (
              <button
                key={ch.id}
                onClick={() => navigate(`/watch/${ch.id}`)}
                className="group bg-[#13131a] border border-[#1f1f2e] rounded-xl overflow-hidden hover:border-red-500/50 hover:scale-105 transition-all duration-200 text-left"
              >
                <div className="aspect-video bg-[#0a0a0f] flex items-center justify-center relative">
                  {ch.logo_url ? (
                    <img src={ch.logo_url} alt={ch.name} className="w-full h-full object-contain p-4" />
                  ) : (
                    <Tv className="w-10 h-10 text-gray-600" />
                  )}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50">
                    <Play className="w-10 h-10 text-white" fill="white" />
                  </div>
                  <span className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                    LIVE
                  </span>
                </div>
                <div className="p-2.5">
                  <p className="text-white text-sm font-semibold truncate">{ch.name}</p>
                  {ch.category && (
                    <p className="text-gray-500 text-xs mt-0.5">{ch.category}</p>
                  )}
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
