import { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '@/integrations/supabase/client'
import { useAuth } from '@/lib/auth-context'

export default function AuthPage() {
  const { user } = useAuth()
  const navigate = useNavigate()

  useEffect(() => {
    if (user) navigate('/')
  }, [user, navigate])

  const loginWithGoogle = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'google',
      options: {
        redirectTo: window.location.origin,
      },
    })
  }

  const loginWithFacebook = async () => {
    await supabase.auth.signInWithOAuth({
      provider: 'facebook',
      options: {
        redirectTo: window.location.origin,
      },
    })
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center px-4">
      <div className="w-full max-w-sm">
        {/* Logo */}
        <div className="flex flex-col items-center mb-8">
          <svg viewBox="0 0 40 40" width="56" height="56" className="mb-3">
            <defs>
              <linearGradient id="nx-g" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
                <stop offset="0" stopColor="#e11d48" />
                <stop offset="1" stopColor="#f97316" />
              </linearGradient>
            </defs>
            <path d="M6 20a14 14 0 0 1 28 0" fill="none" stroke="url(#nx-g)" strokeWidth="2.2" strokeLinecap="round" opacity="0.55" />
            <path d="M11 20a9 9 0 0 1 18 0" fill="none" stroke="url(#nx-g)" strokeWidth="2.2" strokeLinecap="round" opacity="0.85" />
            <circle cx="20" cy="24" r="7.5" fill="url(#nx-g)" />
            <path d="M18 21.2 L24 24 L18 26.8 Z" fill="white" />
          </svg>
          <h1 className="text-2xl font-extrabold text-white">
            <span className="text-red-500">Nexa</span>Live
          </h1>
          <p className="text-gray-400 text-sm mt-1">লাইভ স্ট্রিমিং প্ল্যাটফর্ম</p>
        </div>

        {/* Login Card */}
        <div className="bg-[#13131a] border border-[#1f1f2e] rounded-2xl p-8 shadow-2xl">
          <h2 className="text-white font-bold text-xl text-center mb-2">স্বাগতম!</h2>
          <p className="text-gray-400 text-sm text-center mb-6">
            চালিয়ে যেতে লগিন করুন
          </p>

          {/* Google Button */}
          <button
            onClick={loginWithGoogle}
            className="w-full flex items-center justify-center gap-3 bg-white text-gray-800 font-semibold py-3 px-4 rounded-xl hover:bg-gray-100 transition-all duration-200 mb-3 shadow"
          >
            <svg width="20" height="20" viewBox="0 0 48 48">
              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/>
              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/>
              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/>
            </svg>
            Google দিয়ে Login করুন
          </button>

          {/* Facebook Button */}
          <button
            onClick={loginWithFacebook}
            className="w-full flex items-center justify-center gap-3 bg-[#1877F2] text-white font-semibold py-3 px-4 rounded-xl hover:bg-[#166FE5] transition-all duration-200 shadow"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="white">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            Facebook দিয়ে Login করুন
          </button>

          <p className="text-gray-500 text-xs text-center mt-5">
            Login করে আপনি আমাদের Terms এবং Privacy Policy তে সম্মত হচ্ছেন
          </p>
        </div>
      </div>
    </div>
  )
}
