import { useEffect, useRef, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import Hls from 'hls.js'
import { supabase } from '@/integrations/supabase/client'
import { ArrowLeft, Tv } from 'lucide-react'

interface Channel {
  id: string
  name: string
  stream_url: string
  logo_url?: string
}

export default function WatchPage() {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const videoRef = useRef<HTMLVideoElement>(null)
  const hlsRef = useRef<Hls | null>(null)
  const [channel, setChannel] = useState<Channel | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    if (id) loadChannel(id)
  }, [id])

  const loadChannel = async (channelId: string) => {
    const { data } = await supabase
      .from('channels')
      .select('*')
      .eq('id', channelId)
      .single()

    if (data) {
      setChannel(data)
      if (data.stream_url) initPlayer(data.stream_url)
    }
  }

  const initPlayer = (url: string) => {
    const video = videoRef.current
    if (!video) return

    if (hlsRef.current) {
      hlsRef.current.destroy()
    }

    if (Hls.isSupported()) {
      const hls = new Hls({ lowLatencyMode: true })
      hls.loadSource(url)
      hls.attachMedia(video)
      hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}))
      hls.on(Hls.Events.ERROR, (_e, data) => {
        if (data.fatal) setError('স্ট্রিম লোড করতে সমস্যা হয়েছে')
      })
      hlsRef.current = hls
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = url
      video.play().catch(() => {})
    }
  }

  useEffect(() => {
    return () => hlsRef.current?.destroy()
  }, [])

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-[#0a0a0f]/90 backdrop-blur-xl border-b border-[#1f1f2e]">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center gap-3">
          <button onClick={() => navigate('/')} className="p-2 rounded-lg hover:bg-[#1f1f2e] transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <span className="font-semibold truncate">{channel?.name || 'Loading...'}</span>
        </div>
      </header>

      {/* Player */}
      <div className="max-w-4xl mx-auto px-4 pt-6">
        <div className="bg-black rounded-2xl overflow-hidden aspect-video relative">
          <video
            ref={videoRef}
            className="w-full h-full"
            controls
            playsInline
          />
          {!channel && (
            <div className="absolute inset-0 flex items-center justify-center bg-black">
              <div className="text-center">
                <Tv className="w-12 h-12 mx-auto mb-3 text-gray-600 animate-pulse" />
                <p className="text-gray-400">লোড হচ্ছে...</p>
              </div>
            </div>
          )}
          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black">
              <p className="text-red-400">{error}</p>
            </div>
          )}
        </div>

        {channel && (
          <div className="mt-4 p-4 bg-[#13131a] rounded-xl border border-[#1f1f2e]">
            <div className="flex items-center gap-3">
              {channel.logo_url ? (
                <img src={channel.logo_url} className="w-10 h-10 object-contain" alt={channel.name} />
              ) : (
                <Tv className="w-8 h-8 text-gray-500" />
              )}
              <div>
                <h2 className="font-bold text-lg">{channel.name}</h2>
                <span className="text-xs bg-red-600 text-white px-2 py-0.5 rounded font-bold">● LIVE</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
