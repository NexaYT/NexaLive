import { Link } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useAuth } from "@/lib/auth-context";
import { ChannelSettingsDialog } from "./ChannelSettingsDialog";

export interface ChannelCardData {
  id: string;
  name: string;
  logo_url: string | null;
  description: string | null;
}

// Generate a stable color from the channel name for the letter avatar
function colorFor(name: string) {
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) | 0;
  const hue = Math.abs(h) % 360;
  return `linear-gradient(135deg, hsl(${hue} 70% 35%), hsl(${(hue + 40) % 360} 70% 22%))`;
}

export function ChannelCard({ channel }: { channel: ChannelCardData }) {
  const { isAdmin } = useAuth();
  const [errored, setErrored] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const timerRef = useRef<number | null>(null);
  const longPressed = useRef(false);
  const showImage = channel.logo_url && !errored;
  const letter = (channel.name?.trim()?.[0] ?? "?").toUpperCase();

  const startPress = () => {
    if (!isAdmin) return;
    longPressed.current = false;
    if (timerRef.current) window.clearTimeout(timerRef.current);
    timerRef.current = window.setTimeout(() => {
      longPressed.current = true;
      setEditOpen(true);
      if (navigator.vibrate) try { navigator.vibrate(20); } catch { /* noop */ }
    }, 550);
  };
  const cancelPress = () => {
    if (timerRef.current) { window.clearTimeout(timerRef.current); timerRef.current = null; }
  };
  const onClickCapture: React.MouseEventHandler = (e) => {
    if (longPressed.current) { e.preventDefault(); e.stopPropagation(); longPressed.current = false; }
  };
  const onContextMenu: React.MouseEventHandler = (e) => {
    if (!isAdmin) return;
    e.preventDefault();
    setEditOpen(true);
  };

  return (
    <>
      <Link
        to="/watch/$id"
        params={{ id: channel.id }}
        className="group flex w-20 shrink-0 flex-col items-center gap-1.5 sm:w-24 outline-none select-none"
        onMouseDown={startPress}
        onMouseUp={cancelPress}
        onMouseLeave={cancelPress}
        onTouchStart={startPress}
        onTouchEnd={cancelPress}
        onTouchMove={cancelPress}
        onTouchCancel={cancelPress}
        onClickCapture={onClickCapture}
        onContextMenu={onContextMenu}
      >
        <div className="relative">
          <div className="absolute -inset-[2px] rounded-full bg-gradient-brand opacity-40 blur-sm transition-all duration-300 group-hover:opacity-100 group-focus-visible:opacity-100 group-hover:blur-md" />
          <div
            className="relative h-16 w-16 sm:h-20 sm:w-20 overflow-hidden rounded-full bg-surface ring-2 ring-border/60 transition-all duration-300 group-hover:scale-105 group-focus-visible:scale-105 group-hover:ring-primary group-focus-visible:ring-primary group-focus-visible:ring-4"
            style={!showImage ? { backgroundImage: colorFor(channel.name) } : undefined}
          >
            {showImage ? (
              <img
                src={channel.logo_url!}
                alt={channel.name}
                loading="lazy"
                decoding="async"
                referrerPolicy="no-referrer"
                draggable={false}
                className="h-full w-full object-cover"
                onError={() => setErrored(true)}
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center">
                <span className="text-xl sm:text-2xl font-black text-white/95 drop-shadow">
                  {letter}
                </span>
              </div>
            )}
          </div>
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 flex items-center gap-1 rounded-full bg-red-600 px-1.5 py-0.5 text-[8px] font-black uppercase tracking-wider text-white shadow-lg ring-2 ring-background">
            <span className="h-1 w-1 animate-pulse rounded-full bg-white" />
            LIVE
          </div>
        </div>
        <p className="line-clamp-2 text-center text-xs font-medium leading-tight text-foreground/90 group-hover:text-foreground">
          {channel.name}
        </p>
      </Link>
      {isAdmin && editOpen && (
        <ChannelSettingsDialog channelId={channel.id} open={editOpen} onOpenChange={setEditOpen} />
      )}
    </>
  );
}
