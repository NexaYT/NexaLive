import { useEffect, useRef, useState, useCallback, useMemo } from "react";
import Hls from "hls.js";
import {
  Play, Pause, Volume2, VolumeX, Maximize2, Minimize2, PictureInPicture2,
  RotateCcw, Settings2, Radio, Tv, RefreshCw, Rewind, FastForward, Gauge, Subtitles,
} from "lucide-react";

export type PlayerEngine = "auto" | "hls" | "native" | "mpegts" | "shaka" | "youtube";

function isHlsUrl(url: string) { const u = url.split("?")[0].toLowerCase(); return u.endsWith(".m3u8") || u.includes(".m3u8"); }
function isDashUrl(url: string) { return url.split("?")[0].toLowerCase().endsWith(".mpd"); }
function isTsFlvUrl(url: string) { const u = url.split("?")[0].toLowerCase(); return u.endsWith(".ts") || u.endsWith(".flv"); }
function getYouTubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) return u.pathname.slice(1) || null;
    if (u.hostname.includes("youtube.com")) {
      if (u.pathname === "/watch") return u.searchParams.get("v");
      if (u.pathname.startsWith("/embed/")) return u.pathname.split("/")[2] || null;
      if (u.pathname.startsWith("/live/")) return u.pathname.split("/")[2] || null;
    }
  } catch { /* noop */ }
  return null;
}
function detectEngine(src: string): PlayerEngine {
  if (getYouTubeId(src)) return "youtube";
  if (isHlsUrl(src)) return "hls";
  if (isDashUrl(src)) return "shaka";
  if (isTsFlvUrl(src)) return "mpegts";
  return "native";
}
function toProxyUrl(src: string): string {
  if (!src) return src;
  if (src.startsWith("blob:") || src.startsWith("data:")) return src;
  if (src.startsWith("/api/public/stream/")) return src;
  let parsed: URL;
  try { parsed = new URL(src, typeof window !== "undefined" ? window.location.href : "http://x"); }
  catch { return src; }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return src;
  return `/api/public/stream/p?u=${encodeURIComponent(parsed.toString())}`;
}
function resolveStreamUrl(src: string, useProxy: boolean): string {
  // Route through the edge proxy ONLY when the channel is explicitly flagged
  // use_proxy in its settings. No implicit fallback — direct playback is faster
  // and avoids consuming edge bandwidth.
  if (!src) return src;
  return useProxy ? toProxyUrl(src) : src;
}

const ENGINE_LABEL: Record<PlayerEngine, string> = {
  auto: "Auto", hls: "HLS", native: "Native", mpegts: "MPEG-TS", shaka: "DASH", youtube: "YouTube",
};

const SPEEDS = [0.5, 0.75, 1, 1.25, 1.5, 2] as const;

// MovieBox-style standard quality tiers. We map each real HLS level to the
// nearest tier so the menu always shows familiar labels (144p → 4K) even when
// the manifest exposes odd heights (e.g. 1088, 540).
const QUALITY_TIERS = [
  { h: 2160, label: "4K",    tag: "UHD" },
  { h: 1440, label: "1440p", tag: "QHD" },
  { h: 1080, label: "1080p", tag: "FHD" },
  { h: 720,  label: "720p",  tag: "HD"  },
  { h: 480,  label: "480p",  tag: "SD"  },
  { h: 360,  label: "360p",  tag: ""    },
  { h: 240,  label: "240p",  tag: ""    },
  { h: 144,  label: "144p",  tag: ""    },
] as const;

function nearestTier(height: number) {
  let best = QUALITY_TIERS[QUALITY_TIERS.length - 1];
  let bestDiff = Infinity;
  for (const t of QUALITY_TIERS) {
    const d = Math.abs(t.h - height);
    if (d < bestDiff) { bestDiff = d; best = t; }
  }
  return best;
}

function fmt(t: number) {
  if (!isFinite(t) || t < 0) return "0:00";
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  return h > 0
    ? `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}`
    : `${m}:${s.toString().padStart(2, "0")}`;
}

type HlsLevel = { index: number; height: number; bitrate: number };

export function VideoPlayer({ src, poster, useProxy = false }: { src: string; poster?: string | null; useProxy?: boolean }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const mpegtsRef = useRef<any>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const shakaRef = useRef<any>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [volume, setVolume] = useState(1);
  const [fullscreen, setFullscreen] = useState(false);
  const [attempt, setAttempt] = useState(0);
  const [rotation, setRotation] = useState(0);
  const [engineOverride, setEngineOverride] = useState<PlayerEngine>("auto");
  const [showSettings, setShowSettings] = useState(false);
  const [showControls, setShowControls] = useState(true);
  const [clock, setClock] = useState(() => new Date());
  const [behindLive, setBehindLive] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [speed, setSpeed] = useState<number>(1);
  const [isLive, setIsLive] = useState(true);
  const [seekPct, setSeekPct] = useState<number | null>(null);
  const [levels, setLevels] = useState<HlsLevel[]>([]);
  const [currentLevel, setCurrentLevel] = useState<number>(-1); // -1 = auto
  const [subtitleTracks, setSubtitleTracks] = useState<{ id: number; name: string; lang: string }[]>([]);
  const [currentSub, setCurrentSub] = useState<number>(-1); // -1 = off

  const ytId = useMemo(() => getYouTubeId(src), [src]);
  const effectiveEngine: PlayerEngine = engineOverride === "auto" ? detectEngine(src) : engineOverride;
  const isYouTube = effectiveEngine === "youtube";
  const resolved = isYouTube ? src : resolveStreamUrl(src, useProxy);

  // Live clock
  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const bumpControls = useCallback(() => {
    setShowControls(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => { if (playing) setShowControls(false); }, 3200);
  }, [playing]);

  const retry = useCallback(() => {
    setError(null); setLoading(true); setAttempt((a) => a + 1);
  }, []);

  // Fullscreen state sync
  useEffect(() => {
    const onFs = () => {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const doc = document as any;
      setFullscreen(!!(doc.fullscreenElement || doc.webkitFullscreenElement || doc.msFullscreenElement));
    };
    document.addEventListener("fullscreenchange", onFs);
    document.addEventListener("webkitfullscreenchange", onFs);
    return () => {
      document.removeEventListener("fullscreenchange", onFs);
      document.removeEventListener("webkitfullscreenchange", onFs);
    };
  }, []);

  // Player setup
  useEffect(() => {
    if (isYouTube) return;
    const video = videoRef.current;
    if (!video || !src) return;
    setError(null); setLoading(true);

    const cleanup = () => {
      try { hlsRef.current?.destroy(); } catch { /* noop */ }
      hlsRef.current = null;
      try { mpegtsRef.current?.destroy(); } catch { /* noop */ }
      mpegtsRef.current = null;
      try { shakaRef.current?.destroy(); } catch { /* noop */ }
      shakaRef.current = null;
    };
    cleanup();

    const onLoaded = () => {
      setLoading(false);
      const d = video.duration;
      setDuration(isFinite(d) ? d : 0);
      setIsLive(!isFinite(d) || d === Infinity || d === 0);
      video.play().catch(() => {});
    };
    const onPlay = () => { setPlaying(true); setLoading(false); };
    const onPause = () => setPlaying(false);
    const onVol = () => { setMuted(video.muted); setVolume(video.volume); };
    const onTime = () => {
      setCurrentTime(video.currentTime);
      if (video.buffered.length) {
        const end = video.buffered.end(video.buffered.length - 1);
        setBuffered(end);
        setBehindLive(Math.max(0, end - video.currentTime));
      }
    };
    const onWaiting = () => setLoading(true);
    const onPlaying = () => setLoading(false);
    const onNativeErr = () => {
      if (effectiveEngine !== "native") return;
      setError("Unable to load this stream."); setLoading(false);
    };
    const onRate = () => setSpeed(video.playbackRate);

    video.addEventListener("loadedmetadata", onLoaded);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);
    video.addEventListener("volumechange", onVol);
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("waiting", onWaiting);
    video.addEventListener("playing", onPlaying);
    video.addEventListener("ratechange", onRate);
    video.addEventListener("error", onNativeErr);

    (async () => {
      try {
        if (effectiveEngine === "hls") {
          if (Hls.isSupported()) {
            const hls = new Hls({
              enableWorker: true,
              lowLatencyMode: true,
              backBufferLength: 30,
              maxBufferLength: 15,
              maxMaxBufferLength: 30,
              liveSyncDurationCount: 3,
              liveMaxLatencyDurationCount: 8,
            });
            hlsRef.current = hls;
            hls.loadSource(resolved); hls.attachMedia(video);
            hls.on(Hls.Events.MANIFEST_PARSED, (_e, data) => {
              onLoaded();
              const lvls: HlsLevel[] = (data?.levels ?? hls.levels ?? []).map((l, i) => ({
                index: i, height: l.height ?? 0, bitrate: l.bitrate ?? 0,
              })).filter((l) => l.height > 0 || l.bitrate > 0);
              setLevels(lvls);
              setCurrentLevel(hls.currentLevel);
            });
            hls.on(Hls.Events.LEVEL_SWITCHED, (_e, data) => setCurrentLevel(data.level));
            hls.on(Hls.Events.SUBTITLE_TRACKS_UPDATED, (_e, data) => {
              const tracks = (data?.subtitleTracks ?? []).map((t, i) => ({
                id: i, name: t.name || t.lang || `Track ${i + 1}`, lang: t.lang || "",
              }));
              setSubtitleTracks(tracks);
            });
            hls.on(Hls.Events.SUBTITLE_TRACK_SWITCH, (_e, data) => setCurrentSub(data.id));
            hls.on(Hls.Events.ERROR, (_e, data) => {
              if (!data.fatal) return;
              if (data.type === "networkError") { try { hls.startLoad(); return; } catch { /* noop */ } }
              else if (data.type === "mediaError") { try { hls.recoverMediaError(); return; } catch { /* noop */ } }
              setError(data.type === "networkError" ? "Network error" : "Media error");
              setLoading(false);
            });
          } else {
            video.src = resolved;
          }
        } else if (effectiveEngine === "mpegts") {
          const mod = await import("mpegts.js");
          const mpegts = mod.default;
          if (mpegts.isSupported()) {
            const player = mpegts.createPlayer({
              type: src.toLowerCase().includes(".flv") ? "flv" : "mse",
              url: resolved, isLive: true,
            });
            mpegtsRef.current = player;
            player.attachMediaElement(video);
            player.load();
            Promise.resolve(player.play()).catch(() => {});
          } else {
            setError("MPEG-TS not supported"); setLoading(false);
          }
        } else if (effectiveEngine === "shaka") {
          const shakaMod = await import("shaka-player/dist/shaka-player.compiled.js");
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          const shaka = (shakaMod as any).default ?? shakaMod;
          shaka.polyfill.installAll();
          if (!shaka.Player.isBrowserSupported()) {
            setError("DASH not supported"); setLoading(false); return;
          }
          const player = new shaka.Player(video);
          shakaRef.current = player;
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          player.addEventListener("error", (e: any) => {
            setError("Shaka error: " + (e?.detail?.code ?? "unknown")); setLoading(false);
          });
          await player.load(resolved);
        } else {
          video.src = resolved;
        }
      } catch (e) {
        setError(e instanceof Error ? e.message : "Player failed to load");
        setLoading(false);
      }
    })();

    return () => {
      cleanup();
      video.removeEventListener("loadedmetadata", onLoaded);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      video.removeEventListener("volumechange", onVol);
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("waiting", onWaiting);
      video.removeEventListener("playing", onPlaying);
      video.removeEventListener("ratechange", onRate);
      video.removeEventListener("error", onNativeErr);
    };
  }, [src, attempt, resolved, effectiveEngine, isYouTube]);

  const togglePlay = useCallback(() => {
    const v = videoRef.current; if (!v) return;
    if (v.paused) v.play().catch(() => {}); else v.pause();
  }, []);

  const toggleMute = useCallback(() => {
    const v = videoRef.current; if (!v) return;
    v.muted = !v.muted;
    if (!v.muted && v.volume === 0) v.volume = 1;
  }, []);

  const onVolume = (val: number) => {
    const v = videoRef.current; if (!v) return;
    v.volume = val; v.muted = val === 0;
  };

  const jumpToLive = () => {
    const v = videoRef.current; if (!v) return;
    if (v.buffered.length) {
      v.currentTime = v.buffered.end(v.buffered.length - 1) - 0.5;
      v.play().catch(() => {});
    }
  };

  const seekBy = (delta: number) => {
    const v = videoRef.current; if (!v) return;
    v.currentTime = Math.max(0, Math.min((v.duration || v.currentTime + delta), v.currentTime + delta));
  };

  const seekToPct = (pct: number) => {
    const v = videoRef.current; if (!v || !duration) return;
    v.currentTime = Math.max(0, Math.min(duration, (pct / 100) * duration));
  };

  const changeSpeed = (s: number) => {
    const v = videoRef.current; if (!v) return;
    v.playbackRate = s;
    setSpeed(s);
  };

  const toggleFullscreen = useCallback(() => {
    const el = wrapRef.current;
    if (!el) return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const doc = document as any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const anyEl = el as any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const v = videoRef.current as any;
    const fsEl = doc.fullscreenElement || doc.webkitFullscreenElement || doc.msFullscreenElement;
    if (fsEl) {
      (doc.exitFullscreen || doc.webkitExitFullscreen || doc.msExitFullscreen)?.call(doc);
      return;
    }
    if (v?.webkitEnterFullscreen && !isYouTube) { try { v.webkitEnterFullscreen(); return; } catch { /* noop */ } }
    const req = anyEl.requestFullscreen || anyEl.webkitRequestFullscreen || anyEl.msRequestFullscreen;
    try {
      req?.call(anyEl);
      // Try to lock to landscape on mobile
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const orient = (screen as any).orientation;
      if (orient?.lock) { orient.lock("landscape").catch(() => {}); }
    } catch { /* noop */ }
  }, [isYouTube]);

  const togglePiP = useCallback(async () => {
    const v = videoRef.current;
    if (!v) return;
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const doc = document as any;
      if (doc.pictureInPictureElement) await doc.exitPictureInPicture();
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      else await (v as any).requestPictureInPicture?.();
    } catch { /* noop */ }
  }, []);

  const rotate = () => setRotation((r) => (r + 90) % 360);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement | null;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) return;
      if (!wrapRef.current) return;
      switch (e.key.toLowerCase()) {
        case " ": case "k": e.preventDefault(); togglePlay(); break;
        case "f": e.preventDefault(); toggleFullscreen(); break;
        case "m": e.preventDefault(); toggleMute(); break;
        case "p": e.preventDefault(); togglePiP(); break;
        case "arrowright": if (!isLive) { e.preventDefault(); seekBy(10); } break;
        case "arrowleft": if (!isLive) { e.preventDefault(); seekBy(-10); } break;
        case "arrowup": e.preventDefault(); onVolume(Math.min(1, volume + 0.1)); break;
        case "arrowdown": e.preventDefault(); onVolume(Math.max(0, volume - 0.1)); break;
      }
      bumpControls();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [togglePlay, toggleFullscreen, toggleMute, togglePiP, bumpControls, isLive, volume]);

  const isLiveEdge = behindLive < 5;
  const clockStr = clock.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  const displayPct = seekPct ?? (duration ? (currentTime / duration) * 100 : 0);
  const bufferPct = duration ? Math.min(100, (buffered / duration) * 100) : 0;

  return (
    <div
      ref={wrapRef}
      onMouseMove={bumpControls}
      onTouchStart={bumpControls}
      onClick={bumpControls}
      className="group relative aspect-video w-full overflow-hidden rounded-xl bg-black ring-1 ring-border shadow-elevated"
    >
      {isYouTube && ytId ? (
        <iframe
          key={`${ytId}-${attempt}`}
          src={`https://www.youtube.com/embed/${ytId}?autoplay=1&playsinline=1`}
          className="h-full w-full"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      ) : (
        <video
          ref={videoRef}
          playsInline
          muted={muted}
          poster={poster ?? undefined}
          onClick={togglePlay}
          onDoubleClick={toggleFullscreen}
          className="h-full w-full transition-transform duration-300"
          style={{ transform: rotation ? `rotate(${rotation}deg)` : undefined }}
        />
      )}

      {/* Top-left LIVE badge */}
      <div className="pointer-events-none absolute left-3 top-3 z-20 flex items-center gap-2">
        {isLive && (
          <div className="flex items-center gap-1.5 rounded-md bg-destructive px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-destructive-foreground shadow-lg">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" /> LIVE
          </div>
        )}
      </div>

      {/* Center play overlay when paused */}
      {!isYouTube && !loading && !error && !playing && (
        <button
          onClick={togglePlay}
          className="absolute inset-0 z-10 flex items-center justify-center bg-black/30"
          aria-label="Play"
        >
          <span className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-brand shadow-glow ring-4 ring-white/10">
            <Play className="h-9 w-9 translate-x-0.5 text-primary-foreground" fill="currentColor" />
          </span>
        </button>
      )}

      {/* LOADING */}
      {loading && !error && !isYouTube && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-black/90 backdrop-blur-sm">
          <div className="relative">
            <Tv className="h-20 w-20 text-white/90" strokeWidth={1.5} />
            <span className="absolute bottom-3 left-1/2 h-2 w-2 -translate-x-1/2 animate-pulse rounded-full bg-primary shadow-glow" />
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-white">Connecting…</div>
            <div className="mt-1 text-sm text-white/60">
              {useProxy ? "Routing through secure edge…" : "Tuning stream…"}
            </div>
          </div>
        </div>
      )}

      {/* CONTROL BAR */}
      {!isYouTube && !loading && !error && (
        <div
          className={`absolute inset-x-0 bottom-0 z-20 bg-gradient-to-t from-black/95 via-black/60 to-transparent px-3 pb-2 pt-10 transition-opacity duration-300 ${
            showControls ? "opacity-100" : "opacity-0 pointer-events-none"
          }`}
        >
          {/* Seek bar for VOD */}
          {!isLive && duration > 0 && (
            <div className="mb-2 px-1">
              <div className="relative h-1.5 w-full cursor-pointer rounded-full bg-white/15"
                onClick={(e) => {
                  const r = e.currentTarget.getBoundingClientRect();
                  seekToPct(((e.clientX - r.left) / r.width) * 100);
                }}
              >
                <div className="absolute inset-y-0 left-0 rounded-full bg-white/25" style={{ width: `${bufferPct}%` }} />
                <div className="absolute inset-y-0 left-0 rounded-full bg-gradient-brand" style={{ width: `${displayPct}%` }} />
                <input
                  type="range" min={0} max={100} step={0.1}
                  value={displayPct}
                  onChange={(e) => setSeekPct(parseFloat(e.target.value))}
                  onMouseUp={() => { if (seekPct !== null) { seekToPct(seekPct); setSeekPct(null); } }}
                  onTouchEnd={() => { if (seekPct !== null) { seekToPct(seekPct); setSeekPct(null); } }}
                  className="absolute inset-0 w-full appearance-none bg-transparent opacity-0"
                />
                <div className="absolute -top-1 h-3.5 w-3.5 -translate-x-1/2 rounded-full bg-primary shadow-glow ring-2 ring-black/40"
                  style={{ left: `${displayPct}%` }} />
              </div>
              <div className="mt-1 flex justify-between text-[10px] font-mono tabular-nums text-white/70">
                <span>{fmt(currentTime)}</span>
                <span>{fmt(duration)}</span>
              </div>
            </div>
          )}

          <div className="flex items-center gap-1.5 text-white sm:gap-2">
            <button onClick={togglePlay} className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10">
              {playing ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
            </button>

            {!isLive && (
              <>
                <button onClick={() => seekBy(-10)} className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-white/10 sm:flex" title="Back 10s">
                  <Rewind className="h-4 w-4" />
                </button>
                <button onClick={() => seekBy(10)} className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-white/10 sm:flex" title="Forward 10s">
                  <FastForward className="h-4 w-4" />
                </button>
              </>
            )}

            {isLive && (
              <button
                onClick={jumpToLive}
                title={isLiveEdge ? "You're at LIVE edge" : `Jump to LIVE (behind ${behindLive.toFixed(0)}s)`}
                className={`flex items-center gap-1 rounded-md px-2 py-1 text-[10px] font-bold uppercase tracking-wider transition ${
                  isLiveEdge ? "bg-destructive text-destructive-foreground" : "bg-white/10 text-white/70 hover:bg-white/20"
                }`}
              >
                <Radio className="h-3 w-3" /> Live
              </button>
            )}

            <div className="group/vol flex items-center">
              <button onClick={toggleMute} className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10">
                {muted || volume === 0 ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
              </button>
              <input
                type="range" min={0} max={1} step={0.05}
                value={muted ? 0 : volume}
                onChange={(e) => onVolume(parseFloat(e.target.value))}
                className="hidden h-1 w-0 accent-primary transition-all group-hover/vol:w-20 sm:block sm:group-hover/vol:mx-2"
              />
            </div>

            <div className="mx-auto font-mono text-xs tabular-nums text-white/70">{clockStr}</div>

            <button onClick={rotate} title="Rotate" className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-white/10 sm:flex">
              <RotateCcw className="h-4 w-4" />
            </button>

            <button onClick={togglePiP} title="Picture in Picture" className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-white/10 sm:flex">
              <PictureInPicture2 className="h-4 w-4" />
            </button>
            {subtitleTracks.length > 0 && (
              <button
                onClick={() => {
                  const next = currentSub === -1 ? 0 : -1;
                  if (hlsRef.current) hlsRef.current.subtitleTrack = next;
                  setCurrentSub(next);
                }}
                title={currentSub === -1 ? "Turn on subtitles" : "Turn off subtitles"}
                className={`flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10 ${currentSub !== -1 ? "text-primary" : ""}`}
              >
                <Subtitles className="h-4 w-4" />
              </button>
            )}
            <button onClick={() => setShowSettings((s) => !s)} title="Settings"
              className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10">
              <Settings2 className="h-4 w-4" />
            </button>
            <button onClick={toggleFullscreen} title="Fullscreen (F)"
              className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/10">
              {fullscreen ? <Minimize2 className="h-4 w-4" /> : <Maximize2 className="h-4 w-4" />}
            </button>
          </div>
        </div>
      )}

      {/* Settings dropdown */}
      {showSettings && !isYouTube && (
        <div className="absolute bottom-14 right-3 z-30 max-h-[70vh] w-56 overflow-y-auto rounded-lg bg-black/95 p-2 text-xs text-white shadow-xl ring-1 ring-white/10 backdrop-blur">
          {levels.length > 0 && (
            <>
              <div className="mb-1 flex items-center gap-1.5 px-2 py-1 text-[10px] uppercase tracking-wider text-white/50">
                Quality
              </div>
              <div className="mb-2 space-y-0.5">
                <button
                  onClick={() => { if (hlsRef.current) hlsRef.current.currentLevel = -1; setCurrentLevel(-1); }}
                  className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left hover:bg-white/10 ${
                    currentLevel === -1 ? "bg-white/10 font-semibold text-primary" : ""
                  }`}
                >
                  <span className="flex items-center gap-2">Auto <span className="rounded bg-primary/20 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-primary">ABR</span></span>
                  <span className="text-[9px] text-white/40">recommended</span>
                </button>
                {[...levels].sort((a, b) => b.height - a.height).map((l) => {
                  const tier = nearestTier(l.height || 0);
                  return (
                    <button
                      key={l.index}
                      onClick={() => { if (hlsRef.current) hlsRef.current.currentLevel = l.index; setCurrentLevel(l.index); }}
                      className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left hover:bg-white/10 ${
                        currentLevel === l.index ? "bg-white/10 font-semibold text-primary" : ""
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {l.height > 0 ? tier.label : `${Math.round(l.bitrate / 1000)} kbps`}
                        {tier.tag && l.height > 0 && (
                          <span className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white/70">{tier.tag}</span>
                        )}
                      </span>
                      {l.bitrate > 0 && l.height > 0 && (
                        <span className="text-[9px] text-white/40">{(l.bitrate / 1_000_000).toFixed(1)} Mbps</span>
                      )}
                    </button>
                  );
                })}
              </div>
              <div className="mb-1 border-t border-white/10" />
            </>
          )}
          {subtitleTracks.length > 0 && (
            <>
              <div className="mb-1 flex items-center gap-1.5 px-2 py-1 text-[10px] uppercase tracking-wider text-white/50">
                <Subtitles className="h-3 w-3" /> Subtitles
              </div>
              <div className="mb-2 space-y-0.5">
                <button
                  onClick={() => { if (hlsRef.current) hlsRef.current.subtitleTrack = -1; setCurrentSub(-1); }}
                  className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left hover:bg-white/10 ${currentSub === -1 ? "bg-white/10 font-semibold text-primary" : ""}`}
                >
                  <span>Off</span>
                </button>
                {subtitleTracks.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => { if (hlsRef.current) hlsRef.current.subtitleTrack = t.id; setCurrentSub(t.id); }}
                    className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left hover:bg-white/10 ${currentSub === t.id ? "bg-white/10 font-semibold text-primary" : ""}`}
                  >
                    <span>{t.name}</span>
                    {t.lang && <span className="text-[9px] text-white/40 uppercase">{t.lang}</span>}
                  </button>
                ))}
              </div>
              <div className="mb-1 border-t border-white/10" />
            </>
          )}
          <div className="mb-1 flex items-center gap-1.5 px-2 py-1 text-[10px] uppercase tracking-wider text-white/50">
            <Gauge className="h-3 w-3" /> Speed
          </div>
          <div className="mb-2 grid grid-cols-3 gap-1 px-1">
            {SPEEDS.map((s) => (
              <button
                key={s}
                onClick={() => changeSpeed(s)}
                className={`rounded px-1.5 py-1 text-center text-[11px] transition ${
                  Math.abs(speed - s) < 0.01 ? "bg-primary text-primary-foreground font-bold" : "bg-white/5 hover:bg-white/10"
                }`}
              >{s}x</button>
            ))}
          </div>
          <div className="border-t border-white/10 pt-1">
            <div className="px-2 py-1 text-[10px] uppercase tracking-wider text-white/50">Player Engine</div>
            {(Object.keys(ENGINE_LABEL) as PlayerEngine[]).map((eng) => (
              <button key={eng}
                onClick={() => { setEngineOverride(eng); setShowSettings(false); setAttempt((a) => a + 1); }}
                className={`flex w-full items-center justify-between rounded px-2 py-1.5 text-left hover:bg-white/10 ${
                  engineOverride === eng ? "bg-white/10 font-semibold text-primary" : ""
                }`}
              >
                <span>{ENGINE_LABEL[eng]}</span>
                {engineOverride === "auto" && eng === detectEngine(src) && (
                  <span className="text-[9px] text-white/40">auto</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ERROR */}
      {error && (
        <div className="absolute inset-0 z-30 flex flex-col items-center justify-center gap-4 bg-black/95 p-6 text-center">
          <Tv className="h-14 w-14 text-white/40" />
          <div>
            <p className="font-semibold text-white">{error}</p>
            <p className="mt-1 text-xs text-white/50">The stream could not be reached. It may be region-locked or offline.</p>
          </div>
          <div className="flex gap-2">
            <button onClick={retry}
              className="inline-flex items-center gap-1.5 rounded-full bg-gradient-brand px-4 py-2 text-sm font-semibold text-primary-foreground shadow-glow hover:scale-105 transition-transform">
              <RefreshCw className="h-4 w-4" /> Retry
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
