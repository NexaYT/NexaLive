import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Shield, Trash2, Zap } from "lucide-react";

interface Props {
  channelId: string;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

type Form = {
  name: string;
  stream_url: string;
  logo_url: string;
  description: string;
  use_proxy: boolean;
  featured: boolean;
};

const EMPTY: Form = {
  name: "", stream_url: "", logo_url: "", description: "", use_proxy: false, featured: false,
};

export function ChannelSettingsDialog({ channelId, open, onOpenChange }: Props) {
  const qc = useQueryClient();
  const [form, setForm] = useState<Form>(EMPTY);

  const { data: channel } = useQuery({
    queryKey: ["channel-edit", channelId],
    enabled: open,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("channels").select("*").eq("id", channelId).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (!channel) return;
    setForm({
      name: channel.name ?? "",
      stream_url: channel.stream_url ?? "",
      logo_url: channel.logo_url ?? "",
      description: channel.description ?? "",
      use_proxy: (channel as { use_proxy?: boolean }).use_proxy ?? false,
      featured: channel.featured ?? false,
    });
  }, [channel]);

  const save = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("channels").update({
        name: form.name,
        stream_url: form.stream_url,
        logo_url: form.logo_url || null,
        description: form.description || null,
        use_proxy: form.use_proxy,
        featured: form.featured,
      }).eq("id", channelId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Channel updated");
      qc.invalidateQueries({ queryKey: ["channel", channelId] });
      qc.invalidateQueries({ queryKey: ["channel-edit", channelId] });
      qc.invalidateQueries({ queryKey: ["home-channels-v2"] });
      qc.invalidateQueries({ queryKey: ["channels-all"] });
      qc.invalidateQueries({ queryKey: ["admin-channels"] });
      qc.invalidateQueries({ queryKey: ["related"] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const remove = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.from("channels").delete().eq("id", channelId);
      if (error) throw error;
    },
    onSuccess: () => {
      toast.success("Channel deleted");
      qc.invalidateQueries({ queryKey: ["home-channels-v2"] });
      qc.invalidateQueries({ queryKey: ["channels-all"] });
      qc.invalidateQueries({ queryKey: ["admin-channels"] });
      onOpenChange(false);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-surface max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5 text-primary" /> Channel Settings
          </DialogTitle>
          <DialogDescription className="text-xs">
            Edit name, URL, logo and per-channel proxy routing.
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={(e) => { e.preventDefault(); save.mutate(); }}
          className="space-y-3"
        >
          <div>
            <Label>Name</Label>
            <Input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="bg-background" />
          </div>
          <div>
            <Label>Stream URL</Label>
            <Input required type="url" value={form.stream_url} onChange={(e) => setForm({ ...form, stream_url: e.target.value })} className="bg-background font-mono text-xs" />
          </div>
          <div>
            <Label>Logo URL</Label>
            <Input type="url" value={form.logo_url} onChange={(e) => setForm({ ...form, logo_url: e.target.value })} className="bg-background" />
            {form.logo_url && (
              <img src={form.logo_url} alt="" className="mt-2 h-12 w-12 rounded-full object-cover ring-1 ring-border" onError={(e) => (e.currentTarget.style.display = "none")} />
            )}
          </div>
          <div>
            <Label>Description</Label>
            <Textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-background" />
          </div>

          <div className="rounded-lg border border-border bg-background/50 p-3">
            <label className="flex cursor-pointer items-start justify-between gap-3">
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 text-sm font-semibold">
                  <Zap className="h-4 w-4 text-primary" /> Route through proxy (VPN-lite)
                </div>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  Enable only for streams that need referer/geo bypass. Direct playback is faster and does not consume edge bandwidth.
                </p>
              </div>
              <Switch checked={form.use_proxy} onCheckedChange={(v) => setForm({ ...form, use_proxy: v })} />
            </label>
          </div>

          <label className="flex items-center gap-3 text-sm">
            <Switch checked={form.featured} onCheckedChange={(v) => setForm({ ...form, featured: v })} />
            Featured on home hero
          </label>

          <DialogFooter className="!justify-between">
            <Button
              type="button"
              variant="ghost"
              className="text-destructive hover:bg-destructive/10 hover:text-destructive"
              onClick={() => { if (confirm(`Delete "${form.name}"?`)) remove.mutate(); }}
              disabled={remove.isPending}
            >
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
            <Button type="submit" disabled={save.isPending} className="bg-gradient-brand text-primary-foreground">
              {save.isPending ? "Saving…" : "Save"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
