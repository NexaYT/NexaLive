import { useEffect, useRef, useState } from "react";

// TV-guide style timeline: 24 hours, hourly ticks, red pulsing "now" marker.
// Auto-scrolls to center current time on mobile.
export function EpgBar({ channelName }: { channelName: string }) {
  const [now, setNow] = useState(() => new Date());
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30_000);
    return () => clearInterval(t);
  }, []);

  // Center current time in mobile scroll
  useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const mins = now.getHours() * 60 + now.getMinutes();
    const totalMins = 24 * 60;
    const target = (mins / totalMins) * el.scrollWidth - el.clientWidth / 2;
    el.scrollTo({ left: Math.max(0, target), behavior: "smooth" });
  }, [now]);

  const hours = Array.from({ length: 24 }, (_, i) => i);
  const nowPct = ((now.getHours() * 60 + now.getMinutes()) / (24 * 60)) * 100;
  const label12 = (h: number) => {
    const suffix = h < 12 ? "AM" : "PM";
    const hr = h % 12 === 0 ? 12 : h % 12;
    return `${hr} ${suffix}`;
  };

  return (
    <div className="rounded-xl bg-surface p-3 ring-1 ring-border">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" />
          <span className="text-[10px] font-bold uppercase tracking-wider text-red-500">Now Playing</span>
          <span className="text-xs font-semibold text-foreground">{channelName}</span>
        </div>
        <div className="font-mono text-xs tabular-nums text-muted-foreground">
          {now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </div>
      </div>

      <div ref={scrollRef} className="relative overflow-x-auto overflow-y-hidden">
        <div className="relative h-14 min-w-[900px]">
          {/* Base track */}
          <div className="absolute inset-x-0 top-8 h-1 rounded-full bg-background" />

          {/* Hour ticks */}
          {hours.map((h) => (
            <div key={h} className="absolute top-0 flex flex-col items-center"
              style={{ left: `${(h / 24) * 100}%`, transform: "translateX(-50%)" }}>
              <span className="text-[10px] font-medium text-muted-foreground">{label12(h)}</span>
              <div className="mt-1 h-3 w-px bg-border" />
            </div>
          ))}
          {/* Half-hour minor ticks */}
          {hours.map((h) => (
            <div key={`m${h}`} className="absolute top-[26px] h-1.5 w-px bg-border/60"
              style={{ left: `${((h + 0.5) / 24) * 100}%` }} />
          ))}

          {/* NOW marker */}
          <div className="absolute top-4 z-10 flex flex-col items-center"
            style={{ left: `${nowPct}%`, transform: "translateX(-50%)" }}>
            <div className="rounded bg-red-500 px-1.5 py-0.5 text-[9px] font-black uppercase leading-none tracking-wider text-white shadow-lg">
              NOW
            </div>
            <div className="h-6 w-0.5 bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
            <div className="-mt-1 h-2 w-2 animate-pulse rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.8)]" />
          </div>
        </div>
      </div>
    </div>
  );
}
