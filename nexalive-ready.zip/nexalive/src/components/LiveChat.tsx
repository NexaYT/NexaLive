import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Send, Pencil, Trash2, MessageCircle, Shield } from "lucide-react";
import { toast } from "sonner";

type ChatMessage = {
  id: string;
  channel_id: string;
  nickname: string;
  message: string;
  is_admin: boolean;
  user_id: string | null;
  created_at: string;
};

const NICK_KEY = "nx_nick";
const RATE_LIMIT_MS = 3000;

function sanitize(text: string) {
  return text.replace(/[<>]/g, "").trim();
}
function randomNick() {
  const n = Math.floor(Math.random() * 9000) + 1000;
  return `Guest${n}`;
}
function timeAgo(iso: string) {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

export function LiveChat({ channelId, channelName }: { channelId: string; channelName: string }) {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [nickname, setNickname] = useState<string>("");
  const [editingNick, setEditingNick] = useState(false);
  const [draftNick, setDraftNick] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const lastSentRef = useRef(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const atBottomRef = useRef(true);

  // Nickname bootstrap
  useEffect(() => {
    if (typeof window === "undefined") return;
    const stored = localStorage.getItem(NICK_KEY);
    if (stored) setNickname(stored);
    else {
      const n = randomNick();
      localStorage.setItem(NICK_KEY, n);
      setNickname(n);
    }
  }, []);

  // Admin check
  useEffect(() => {
    if (!user) { setIsAdmin(false); return; }
    supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle()
      .then(({ data }) => setIsAdmin(!!data));
  }, [user]);

  // Load + realtime
  useEffect(() => {
    if (!channelId) return;
    let alive = true;
    (async () => {
      const { data } = await supabase
        .from("chat_messages")
        .select("*")
        .eq("channel_id", channelId)
        .order("created_at", { ascending: false })
        .limit(50);
      if (!alive) return;
      setMessages((data ?? []).reverse() as ChatMessage[]);
    })();

    const channel = supabase
      .channel(`chat:${channelId}:${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages", filter: `channel_id=eq.${channelId}` },
        (payload) => setMessages((m) => [...m, payload.new as ChatMessage].slice(-200)))
      .on("postgres_changes",
        { event: "DELETE", schema: "public", table: "chat_messages", filter: `channel_id=eq.${channelId}` },
        (payload) => setMessages((m) => m.filter((x) => x.id !== (payload.old as ChatMessage).id)))
      .subscribe();

    return () => { alive = false; supabase.removeChannel(channel); };
  }, [channelId]);

  // Auto-scroll to bottom on new messages if user was at bottom
  useEffect(() => {
    if (!atBottomRef.current) return;
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    atBottomRef.current = el.scrollHeight - el.scrollTop - el.clientHeight < 60;
  };

  const send = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const now = Date.now();
    if (now - lastSentRef.current < RATE_LIMIT_MS) {
      toast.error(`Please wait ${Math.ceil((RATE_LIMIT_MS - (now - lastSentRef.current)) / 1000)}s`);
      return;
    }
    const msg = sanitize(input);
    const nick = sanitize(nickname);
    if (!msg || !nick) return;
    if (msg.length > 300) { toast.error("Message too long"); return; }
    setSending(true);
    const { error } = await supabase.from("chat_messages").insert({
      channel_id: channelId,
      nickname: nick.slice(0, 24),
      message: msg.slice(0, 300),
      user_id: user?.id ?? null,
      is_admin: isAdmin,
    });
    setSending(false);
    if (error) { toast.error(error.message); return; }
    lastSentRef.current = now;
    setInput("");
  };

  const saveNick = () => {
    const n = sanitize(draftNick).slice(0, 24);
    if (!n) return;
    localStorage.setItem(NICK_KEY, n);
    setNickname(n);
    setEditingNick(false);
  };

  const deleteMsg = async (id: string) => {
    const { error } = await supabase.from("chat_messages").delete().eq("id", id);
    if (error) toast.error(error.message);
  };

  return (
    <div className="flex h-full min-h-[520px] flex-col overflow-hidden rounded-xl bg-surface ring-1 ring-border">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-border px-4 py-3">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-4 w-4 text-primary" />
          <div>
            <div className="text-sm font-bold">Live Chat</div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground">{channelName}</div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" />
          <span className="text-[10px] font-semibold uppercase tracking-wider text-red-500">Live</span>
        </div>
      </div>

      {/* Messages */}
      <div ref={scrollRef} onScroll={onScroll}
        className="flex-1 space-y-2 overflow-y-auto px-3 py-3 text-sm scroll-smooth">
        {messages.length === 0 && (
          <div className="flex h-full items-center justify-center py-10 text-center text-xs text-muted-foreground">
            Be the first to say something 👋
          </div>
        )}
        {messages.map((m) => (
          <div key={m.id} className="group flex items-start gap-2 rounded-md px-2 py-1 hover:bg-background/40">
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline gap-1.5">
                <span className={`truncate text-xs font-bold ${m.is_admin ? "text-primary" : "text-foreground/90"}`}>
                  {m.nickname}
                </span>
                {m.is_admin && (
                  <span className="inline-flex items-center gap-0.5 rounded bg-primary/15 px-1 py-0 text-[9px] font-bold uppercase text-primary">
                    <Shield className="h-2.5 w-2.5" /> Admin
                  </span>
                )}
                <span className="text-[10px] text-muted-foreground">{timeAgo(m.created_at)}</span>
              </div>
              <div className="break-words text-[13px] leading-snug text-foreground/90">{m.message}</div>
            </div>
            {isAdmin && (
              <button onClick={() => deleteMsg(m.id)}
                className="opacity-0 transition-opacity group-hover:opacity-100"
                title="Delete">
                <Trash2 className="h-3.5 w-3.5 text-destructive" />
              </button>
            )}
          </div>
        ))}
      </div>

      {/* Nickname bar */}
      <div className="flex items-center gap-2 border-t border-border bg-background/40 px-3 py-2 text-xs">
        <span className="text-muted-foreground">You:</span>
        {editingNick ? (
          <>
            <input autoFocus value={draftNick} onChange={(e) => setDraftNick(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && saveNick()}
              maxLength={24}
              className="min-w-0 flex-1 rounded bg-surface px-2 py-1 text-xs ring-1 ring-border focus:outline-none focus:ring-primary" />
            <button onClick={saveNick} className="rounded bg-primary px-2 py-1 text-[10px] font-bold text-primary-foreground">Save</button>
          </>
        ) : (
          <>
            <span className="font-bold text-foreground">{nickname}</span>
            <button onClick={() => { setDraftNick(nickname); setEditingNick(true); }}
              className="ml-auto flex items-center gap-1 text-muted-foreground hover:text-foreground">
              <Pencil className="h-3 w-3" /> Change
            </button>
          </>
        )}
      </div>

      {/* Composer */}
      <form onSubmit={send} className="flex items-center gap-2 border-t border-border p-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          maxLength={300}
          placeholder="Say something..."
          className="min-w-0 flex-1 rounded-full bg-background px-4 py-2 text-sm ring-1 ring-border focus:outline-none focus:ring-primary"
        />
        <button type="submit" disabled={sending || !input.trim()}
          className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-brand text-primary-foreground shadow-glow transition-transform hover:scale-105 disabled:opacity-50">
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
